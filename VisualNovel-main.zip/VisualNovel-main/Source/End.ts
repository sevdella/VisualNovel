namespace Template {
    export async function End(): ƒS.SceneReturn {/**/}
}
