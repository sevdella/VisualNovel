namespace Template {
    export async function Truth(): ƒS.SceneReturn {
        console.log("Truth");


        

    }
}